package com.bankonet.model;

import java.util.List;

public class Client{
	
	private String login;
	private String nom;
	private String prenom;
	private List<Compte> comptes;
	
	
}
